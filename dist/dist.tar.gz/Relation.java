/**
 * TerenceLyu
 * blu96@brandeis.edu
 * cs127_pa3
 * 2019/4/12
 */
public class Relation
{
	public String[] col;
	public int rowCount;
	public int colCount;
	
	public Relation(String[] col, int rowCount, int colCount)
	{
		this.col = col;
		this.rowCount = rowCount;
		this.colCount = colCount;
	}
}
