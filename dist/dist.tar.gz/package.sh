rm -f proc_stderr proc_stdout
rm -rf *.tar.gz
tar czvf dist.tar.gz *
