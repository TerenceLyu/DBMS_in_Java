#!/usr/bin/env bash
javac Main.java
